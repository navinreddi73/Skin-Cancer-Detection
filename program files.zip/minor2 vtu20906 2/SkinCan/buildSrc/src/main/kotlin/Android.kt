object Android {
    val applicationId = "io.github.skincanorg.skincan"
    val compileSdk = 32
    val minSdk = 23
    val targetSdk = 32
    val versionCode = 4
    val versionName = "0.0.4"
}
